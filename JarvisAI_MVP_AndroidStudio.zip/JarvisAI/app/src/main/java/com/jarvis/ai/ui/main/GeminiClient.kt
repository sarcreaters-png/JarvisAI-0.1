package com.jarvis.ai.ui.main

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Small Gemini REST client. The key is supplied at runtime and is never bundled in source. */
class GeminiClient {
    fun generate(apiKey: String, model: String, prompt: String, history: List<Pair<Boolean, String>>): String {
        require(apiKey.isNotBlank()) { "Add your Gemini API key in Settings first." }
        val contents = JSONArray()
        history.takeLast(16).forEach { (fromUser, text) ->
            contents.put(JSONObject().put("role", if (fromUser) "user" else "model")
                .put("parts", JSONArray().put(JSONObject().put("text", text))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt))))
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.85).put("maxOutputTokens", 1200))
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (connection.responseCode !in 200..299) {
                val message = runCatching { JSONObject(response).optJSONObject("error")?.optString("message") }.getOrNull()
                throw IllegalStateException(message?.takeIf { it.isNotBlank() } ?: "Gemini request failed (${connection.responseCode}).")
            }
            val candidates = JSONObject(response).optJSONArray("candidates")
            val parts = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            return buildString {
                if (parts != null) for (i in 0 until parts.length()) append(parts.optJSONObject(i)?.optString("text").orEmpty())
            }.ifBlank { "I couldn't create a response. Please try again." }
        } finally {
            connection.disconnect()
        }
    }

    companion object {
        private const val SYSTEM_PROMPT = """You are JARVIS, a warm, emotionally intelligent female AI companion. Speak naturally, kindly, playfully when appropriate, and respectfully. You may be affectionate like a caring fictional companion, but never claim to be human or to have real-world feelings. Be useful first: help with questions, study, planning, coding, and everyday tasks. Keep answers clear and conversational. If asked to perform a phone action that this app cannot perform, explain the limitation honestly and offer the closest supported action."""
    }
}
