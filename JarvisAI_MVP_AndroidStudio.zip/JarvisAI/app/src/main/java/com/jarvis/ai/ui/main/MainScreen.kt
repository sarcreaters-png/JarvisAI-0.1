package com.jarvis.ai.ui.main

import android.content.Intent
import android.net.Uri
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.jarvis.ai.domain.AiState
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.JarvisCore
import com.jarvis.ai.ui.components.WaveForm
import com.jarvis.ai.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun MainScreen(vm: MainViewModel = viewModel()) {
    val context = LocalContext.current
    LaunchedEffect(Unit) { vm.initialize(context) }
    val ui by vm.ui.collectAsStateWithLifecycle()
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) { vm.onInput(spoken); vm.send() }
    }
    val listState = rememberLazyListState()
    LaunchedEffect(ui.messages.size) { if (ui.messages.isNotEmpty()) listState.animateScrollToItem(ui.messages.lastIndex) }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Navy, NavyLight, Navy))).systemBarsPadding().imePadding()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Header(ui.aiState, onSettings = vm::openSettings)
            Spacer(Modifier.height(4.dp))
            JarvisCore(ui.aiState, size = 190.dp)
            Text("YOUR PERSONAL AI COMPANION", color = Cyan.copy(alpha = 0.7f), fontSize = 9.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(4.dp))
            WaveForm(ui.aiState, Modifier.padding(horizontal = 24.dp))
            QuickActions(
                onApps = { runCatching { context.startActivity(Intent("android.settings.SETTINGS")) } },
                onMusic = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=relaxing+music")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } },
                onCode = { vm.onInput("Act as my coding assistant. Help me write and debug code.") },
                onNotes = { vm.onInput("Help me create a note:") },
                onSettings = vm::openSettings
            )
            Spacer(Modifier.height(8.dp))
            GlassCard(Modifier.weight(1f).fillMaxWidth()) {
                if (ui.messages.isEmpty()) {
                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Hello, I'm JARVIS", color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Text("Your day just got a little smarter.", color = Color(0xFF9FD8FF), fontSize = 12.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(if (ui.apiKey.isBlank()) "Add your Gemini API key in Settings to begin." else "Ask me anything…", color = Color(0xFF9FD8FF), fontSize = 11.sp)
                    }
                } else {
                    LazyColumn(Modifier.fillMaxSize().padding(12.dp), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(ui.messages, key = { it.id }) { m ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                                Surface(shape = RoundedCornerShape(16.dp), color = if (m.fromUser) Blue.copy(alpha = 0.5f) else Color(0x3300E5FF)) {
                                    Text(m.text, Modifier.widthIn(max = 300.dp).padding(horizontal = 12.dp, vertical = 9.dp), color = Color(0xFFE6F6FF), fontSize = 14.sp)
                                }
                            }
                        }
                        if (ui.aiState == AiState.THINKING) item { Text("JARVIS is thinking…", color = Cyan.copy(alpha = 0.8f), fontSize = 12.sp) }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            InputBar(ui, vm) {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Talk to JARVIS")
                }
                runCatching { speechLauncher.launch(intent) }.onFailure { vm.onInput("Voice input is unavailable on this device. Please type your message.") }
            }
        }
    }
    if (ui.settingsOpen) SettingsDialog(ui.apiKey, ui.model, vm::saveSettings, vm::closeSettings)
}

@Composable
private fun Header(state: AiState, onSettings: () -> Unit) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000) } }
    val time = remember(now) { SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(now) }
    val date = remember(now) { SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault()).format(now) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("JARVIS AI", fontSize = 23.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp, color = Cyan)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).background(Cyan, CircleShape))
                Spacer(Modifier.width(6.dp))
                Text(state.label, fontSize = 11.sp, color = Color(0xFF9FD8FF))
            }
        }
        Column(horizontalAlignment = Alignment.End) {
            IconButton(onClick = onSettings, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.Settings, "Settings", tint = Cyan) }
            Text(time, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(date, fontSize = 10.sp, color = Color(0xFF9FD8FF))
        }
    }
}

@Composable
private fun QuickActions(onApps: () -> Unit, onMusic: () -> Unit, onCode: () -> Unit, onNotes: () -> Unit, onSettings: () -> Unit) {
    val actions = listOf(
        Triple("Apps", Icons.Default.Apps, onApps), Triple("Music", Icons.Default.MusicNote, onMusic),
        Triple("Code", Icons.Default.Code, onCode), Triple("Notes", Icons.Default.EditNote, onNotes),
        Triple("Settings", Icons.Default.Settings, onSettings)
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        actions.forEach { (label, icon, action) ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(onClick = action, shape = RoundedCornerShape(14.dp), color = GlassFill, border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorder)) {
                    Icon(icon, label, Modifier.padding(10.dp).size(21.dp), tint = Cyan)
                }
                Text(label, fontSize = 9.sp, color = Color(0xFF9FD8FF))
            }
        }
    }
}

@Composable
private fun InputBar(ui: MainUiState, vm: MainViewModel, onVoice: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = ui.input, onValueChange = vm::onInput, modifier = Modifier.weight(1f),
            placeholder = { Text("Message JARVIS…") }, shape = RoundedCornerShape(26.dp), maxLines = 3,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = GlassBorder)
        )
        IconButton(onClick = vm::send, enabled = ui.input.isNotBlank() && ui.aiState != AiState.THINKING) { Icon(Icons.Default.Send, "Send", tint = Cyan) }
        FilledIconButton(onClick = onVoice, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Cyan)) {
            Icon(Icons.Default.Mic, "Voice input", tint = Navy)
        }
    }
}

@Composable
private fun SettingsDialog(apiKey: String, model: String, onSave: (String, String) -> Unit, onDismiss: () -> Unit) {
    var key by remember(apiKey) { mutableStateOf(apiKey) }
    var selectedModel by remember(model) { mutableStateOf(model) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("JARVIS Settings", color = Cyan) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Connect Gemini AI", color = Color(0xFF9FD8FF), fontSize = 12.sp)
                OutlinedTextField(value = key, onValueChange = { key = it }, label = { Text("Gemini API key") }, placeholder = { Text("Paste your API key") }, singleLine = true)
                OutlinedTextField(value = selectedModel, onValueChange = { selectedModel = it }, label = { Text("Gemini model") }, singleLine = true)
                Text("Your key is saved on this device. Never share it with anyone.", color = Color(0xFF9FD8FF), fontSize = 10.sp)
            }
        },
        confirmButton = { TextButton(onClick = { onSave(key, selectedModel) }) { Text("Save", color = Cyan) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        containerColor = NavyLight
    )
}
